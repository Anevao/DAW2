<?php
//primera llamada a la vista, el principal es un html de portada
require_once("./vista/principal.html");

?>