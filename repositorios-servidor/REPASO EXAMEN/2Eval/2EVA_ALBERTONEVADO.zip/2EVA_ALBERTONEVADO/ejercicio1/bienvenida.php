<?php
if($veces>1)
{
echo "<h1>BIENVENID@ DE NUEVO ".$usu."<bR> ACCESO: " .$veces." veces</h1>";
}else{
    echo "<h1>BIENVENID@ ".$usu."</h1>";
}